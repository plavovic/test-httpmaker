Open index.html in a browser or deploy this folder to any static host. No HTTPMAKER editor or AI code is included.
